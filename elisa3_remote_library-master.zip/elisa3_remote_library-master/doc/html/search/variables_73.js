var searchData=
[
  ['selector',['selector',['../elisa3-lib_8c.html#a246eb1d61bc00eb091272d29416efe88',1,'elisa3-lib.c']]],
  ['sleepenabledflag',['sleepEnabledFlag',['../elisa3-lib_8c.html#a32395777981e117e6afd2791fdfb155f',1,'elisa3-lib.c']]],
  ['smallleds',['smallLeds',['../elisa3-lib_8c.html#a44d05586880d84f6dc0215902d249a2b',1,'elisa3-lib.c']]],
  ['stoptransmissionflag',['stopTransmissionFlag',['../elisa3-lib_8c.html#a84bce4fc31941251b12d85e504303a01',1,'elisa3-lib.c']]]
];
