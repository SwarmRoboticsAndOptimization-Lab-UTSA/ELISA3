var searchData=
[
  ['flagsrx',['flagsRX',['../elisa3-lib_8c.html#a791be530e4d3ce43da27e91b7cbdbe01',1,'elisa3-lib.c']]],
  ['flagstx',['flagsTX',['../elisa3-lib_8c.html#ae9f352d19ca3bdba83664f15fb4d04f7',1,'elisa3-lib.c']]]
];
