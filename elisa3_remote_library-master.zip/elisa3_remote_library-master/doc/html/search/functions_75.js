var searchData=
[
  ['usb_5freceive',['usb_receive',['../usb-comm_8c.html#aa5f15d2883e51e35be36b680db5f08d6',1,'usb_receive(char *data, int nbytes):&#160;usb-comm.c'],['../usb-comm_8h.html#aa5f15d2883e51e35be36b680db5f08d6',1,'usb_receive(char *data, int nbytes):&#160;usb-comm.c']]],
  ['usb_5fsend',['usb_send',['../usb-comm_8c.html#aab9500debd97cac679a8fdb5e1f69a64',1,'usb_send(char *data, int nbytes):&#160;usb-comm.c'],['../usb-comm_8h.html#aab9500debd97cac679a8fdb5e1f69a64',1,'usb_send(char *data, int nbytes):&#160;usb-comm.c']]]
];
