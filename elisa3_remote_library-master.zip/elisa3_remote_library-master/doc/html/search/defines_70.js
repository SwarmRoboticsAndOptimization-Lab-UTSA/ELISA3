var searchData=
[
  ['packets_5fsize',['PACKETS_SIZE',['../elisa3-lib_8c.html#a39922d187622d716e9b373b6b3a2947f',1,'elisa3-lib.c']]],
  ['payload_5fsize',['PAYLOAD_SIZE',['../elisa3-lib_8c.html#a3fb2dea7d964f6ed95dfac2897c4001d',1,'elisa3-lib.c']]]
];
