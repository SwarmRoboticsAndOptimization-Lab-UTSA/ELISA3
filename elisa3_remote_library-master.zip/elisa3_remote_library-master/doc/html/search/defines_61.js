var searchData=
[
  ['addr_5fsize',['ADDR_SIZE',['../elisa3-lib_8c.html#acfe2aa658c61f71e0a185bcff3008a00',1,'elisa3-lib.c']]],
  ['all_5fir_5foff',['ALL_IR_OFF',['../elisa3-lib_8c.html#aca5f40a44913963425c26e1ede1df054',1,'elisa3-lib.c']]],
  ['all_5fir_5fon',['ALL_IR_ON',['../elisa3-lib_8c.html#a9882c360098ed951d474acae9aa65a49',1,'elisa3-lib.c']]]
];
