var searchData=
[
  ['calibration_5foff',['CALIBRATION_OFF',['../elisa3-lib_8c.html#a0eb5973b309da6146e2253f6d92645f5',1,'elisa3-lib.c']]],
  ['calibration_5fon',['CALIBRATION_ON',['../elisa3-lib_8c.html#aed2b928b2ca67598b3c5dd6b03f6895d',1,'elisa3-lib.c']]],
  ['cliff_5favoid_5foff',['CLIFF_AVOID_OFF',['../elisa3-lib_8c.html#a147a4cee41f04a48f65e40176d82fe19',1,'elisa3-lib.c']]],
  ['cliff_5favoid_5fon',['CLIFF_AVOID_ON',['../elisa3-lib_8c.html#a4f69d0671e54be07441484b8297d387f',1,'elisa3-lib.c']]]
];
