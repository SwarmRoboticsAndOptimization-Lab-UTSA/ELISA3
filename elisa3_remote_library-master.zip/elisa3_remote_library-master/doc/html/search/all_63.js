var searchData=
[
  ['calibrateodomsent',['calibrateOdomSent',['../elisa3-lib_8c.html#a65f08b9178d585189e6ea045255fcf28',1,'elisa3-lib.c']]],
  ['calibratesensors',['calibrateSensors',['../elisa3-lib_8c.html#a9f9a5273f76aa9bca15f2f2bb49b991f',1,'calibrateSensors(int robotAddr):&#160;elisa3-lib.c'],['../elisa3-lib_8h.html#a9f9a5273f76aa9bca15f2f2bb49b991f',1,'calibrateSensors(int robotAddr):&#160;elisa3-lib.c']]],
  ['calibratesensorsforall',['calibrateSensorsForAll',['../elisa3-lib_8c.html#a276879b9acc34056c23ea8894df0441f',1,'calibrateSensorsForAll():&#160;elisa3-lib.c'],['../elisa3-lib_8h.html#a276879b9acc34056c23ea8894df0441f',1,'calibrateSensorsForAll():&#160;elisa3-lib.c']]],
  ['calibration_5foff',['CALIBRATION_OFF',['../elisa3-lib_8c.html#a0eb5973b309da6146e2253f6d92645f5',1,'elisa3-lib.c']]],
  ['calibration_5fon',['CALIBRATION_ON',['../elisa3-lib_8c.html#aed2b928b2ca67598b3c5dd6b03f6895d',1,'elisa3-lib.c']]],
  ['calibrationsent',['calibrationSent',['../elisa3-lib_8c.html#a1b56b1dc502a96e85b07739d6f1b7db9',1,'elisa3-lib.c']]],
  ['checkconcurrency',['checkConcurrency',['../elisa3-lib_8c.html#a1ebb5c52ab16d1bde711cbcee07bb764',1,'elisa3-lib.c']]],
  ['cliff_5favoid_5foff',['CLIFF_AVOID_OFF',['../elisa3-lib_8c.html#a147a4cee41f04a48f65e40176d82fe19',1,'elisa3-lib.c']]],
  ['cliff_5favoid_5fon',['CLIFF_AVOID_ON',['../elisa3-lib_8c.html#a4f69d0671e54be07441484b8297d387f',1,'elisa3-lib.c']]],
  ['closecommunication',['closeCommunication',['../usb-comm_8c.html#ac7edde9fa3bcdfaee12ffe20e5960fcd',1,'closeCommunication():&#160;usb-comm.c'],['../usb-comm_8h.html#ac7edde9fa3bcdfaee12ffe20e5960fcd',1,'closeCommunication():&#160;usb-comm.c']]],
  ['computeverticalangle',['computeVerticalAngle',['../elisa3-lib_8c.html#ab027d820a58cc8a741ae8c95a6c6afaa',1,'elisa3-lib.c']]],
  ['currnumrobots',['currNumRobots',['../elisa3-lib_8c.html#a1ebeee47cb5c6f52ba85f9357a9ba89e',1,'elisa3-lib.c']]],
  ['currpacketid',['currPacketId',['../elisa3-lib_8c.html#aacb56f57f16a36e633640a807e5429fd',1,'elisa3-lib.c']]]
];
