var searchData=
[
  ['proxambientvalue',['proxAmbientValue',['../elisa3-lib_8c.html#a51f94d0e3ab987256037600a96218528',1,'elisa3-lib.c']]],
  ['proxvalue',['proxValue',['../elisa3-lib_8c.html#a2c27d1b09c3446dc0698b8dff045f529',1,'elisa3-lib.c']]]
];
