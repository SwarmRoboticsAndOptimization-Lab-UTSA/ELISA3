var searchData=
[
  ['elisa3_2dlib_2ec',['elisa3-lib.c',['../elisa3-lib_8c.html',1,'']]],
  ['elisa3_2dlib_2eh',['elisa3-lib.h',['../elisa3-lib_8h.html',1,'']]],
  ['enablecliffavoidance',['enableCliffAvoidance',['../elisa3-lib_8c.html#ad1ea7f8ca9c13236329d56c96311ad5d',1,'enableCliffAvoidance(int robotAddr):&#160;elisa3-lib.c'],['../elisa3-lib_8h.html#ad1ea7f8ca9c13236329d56c96311ad5d',1,'enableCliffAvoidance(int robotAddr):&#160;elisa3-lib.c']]],
  ['enableobstacleavoidance',['enableObstacleAvoidance',['../elisa3-lib_8c.html#ab30367a75527675e18846d1cc72aab8e',1,'enableObstacleAvoidance(int robotAddr):&#160;elisa3-lib.c'],['../elisa3-lib_8h.html#ab30367a75527675e18846d1cc72aab8e',1,'enableObstacleAvoidance(int robotAddr):&#160;elisa3-lib.c']]],
  ['enablesleep',['enableSleep',['../elisa3-lib_8c.html#a569c1a9135ac8ec2cd266cc57956e77e',1,'enableSleep(int robotAddr):&#160;elisa3-lib.c'],['../elisa3-lib_8h.html#a569c1a9135ac8ec2cd266cc57956e77e',1,'enableSleep(int robotAddr):&#160;elisa3-lib.c']]],
  ['enabletvremote',['enableTVRemote',['../elisa3-lib_8c.html#a4591d4723913f35017caff804defe98b',1,'enableTVRemote(int robotAddr):&#160;elisa3-lib.c'],['../elisa3-lib_8h.html#a4591d4723913f35017caff804defe98b',1,'enableTVRemote(int robotAddr):&#160;elisa3-lib.c']]],
  ['errorpercentage',['errorPercentage',['../elisa3-lib_8c.html#a369c5c83c63d859e0595240e12e34a49',1,'elisa3-lib.c']]]
];
