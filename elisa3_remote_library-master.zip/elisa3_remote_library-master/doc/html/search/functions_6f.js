var searchData=
[
  ['opencommunication',['openCommunication',['../usb-comm_8c.html#a40ee7e585291ad1086c68b5e3f57e8c1',1,'openCommunication():&#160;usb-comm.c'],['../usb-comm_8h.html#a40ee7e585291ad1086c68b5e3f57e8c1',1,'openCommunication():&#160;usb-comm.c']]]
];
