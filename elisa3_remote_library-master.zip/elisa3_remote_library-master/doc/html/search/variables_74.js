var searchData=
[
  ['tvremote',['tvRemote',['../elisa3-lib_8c.html#a15de6d2d54a817fd54caaac78a9d308f',1,'elisa3-lib.c']]],
  ['tx_5fbuffer',['TX_buffer',['../elisa3-lib_8c.html#a0855ad04c0d4bebd7be7a4f97396b77f',1,'elisa3-lib.c']]]
];
