var searchData=
[
  ['calibratesensors',['calibrateSensors',['../elisa3-lib_8c.html#a9f9a5273f76aa9bca15f2f2bb49b991f',1,'calibrateSensors(int robotAddr):&#160;elisa3-lib.c'],['../elisa3-lib_8h.html#a9f9a5273f76aa9bca15f2f2bb49b991f',1,'calibrateSensors(int robotAddr):&#160;elisa3-lib.c']]],
  ['calibratesensorsforall',['calibrateSensorsForAll',['../elisa3-lib_8c.html#a276879b9acc34056c23ea8894df0441f',1,'calibrateSensorsForAll():&#160;elisa3-lib.c'],['../elisa3-lib_8h.html#a276879b9acc34056c23ea8894df0441f',1,'calibrateSensorsForAll():&#160;elisa3-lib.c']]],
  ['checkconcurrency',['checkConcurrency',['../elisa3-lib_8c.html#a1ebb5c52ab16d1bde711cbcee07bb764',1,'elisa3-lib.c']]],
  ['closecommunication',['closeCommunication',['../usb-comm_8c.html#ac7edde9fa3bcdfaee12ffe20e5960fcd',1,'closeCommunication():&#160;usb-comm.c'],['../usb-comm_8h.html#ac7edde9fa3bcdfaee12ffe20e5960fcd',1,'closeCommunication():&#160;usb-comm.c']]],
  ['computeverticalangle',['computeVerticalAngle',['../elisa3-lib_8c.html#ab027d820a58cc8a741ae8c95a6c6afaa',1,'elisa3-lib.c']]]
];
