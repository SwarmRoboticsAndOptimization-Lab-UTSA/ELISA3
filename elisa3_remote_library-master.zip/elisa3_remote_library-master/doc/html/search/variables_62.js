var searchData=
[
  ['batteryadc',['batteryAdc',['../elisa3-lib_8c.html#aa6147fabc094e676515597e5ffee1eed',1,'elisa3-lib.c']]],
  ['batterypercent',['batteryPercent',['../elisa3-lib_8c.html#a4353ab1628e34259b2ea891cb6c5be93',1,'elisa3-lib.c']]],
  ['blueled',['blueLed',['../elisa3-lib_8c.html#a891833fb4e0a825ff2c08aaf02881a7f',1,'elisa3-lib.c']]]
];
