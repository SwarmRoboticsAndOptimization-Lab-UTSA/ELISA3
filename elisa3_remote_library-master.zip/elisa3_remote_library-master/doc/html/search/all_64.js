var searchData=
[
  ['disablecliffavoidance',['disableCliffAvoidance',['../elisa3-lib_8c.html#abfcd5b8cb8d71a8928f83ee29c605c66',1,'disableCliffAvoidance(int robotAddr):&#160;elisa3-lib.c'],['../elisa3-lib_8h.html#abfcd5b8cb8d71a8928f83ee29c605c66',1,'disableCliffAvoidance(int robotAddr):&#160;elisa3-lib.c']]],
  ['disableobstacleavoidance',['disableObstacleAvoidance',['../elisa3-lib_8c.html#ac03bc126b2f5856c699856dc8730b991',1,'disableObstacleAvoidance(int robotAddr):&#160;elisa3-lib.c'],['../elisa3-lib_8h.html#ac03bc126b2f5856c699856dc8730b991',1,'disableObstacleAvoidance(int robotAddr):&#160;elisa3-lib.c']]],
  ['disablesleep',['disableSleep',['../elisa3-lib_8c.html#abea0a979e3225ea933ae33880ca86ac2',1,'disableSleep(int robotAddr):&#160;elisa3-lib.c'],['../elisa3-lib_8h.html#abea0a979e3225ea933ae33880ca86ac2',1,'disableSleep(int robotAddr):&#160;elisa3-lib.c']]],
  ['disabletvremote',['disableTVRemote',['../elisa3-lib_8c.html#a8cfe0b3be739283132678d9d832588eb',1,'disableTVRemote(int robotAddr):&#160;elisa3-lib.c'],['../elisa3-lib_8h.html#a8cfe0b3be739283132678d9d832588eb',1,'disableTVRemote(int robotAddr):&#160;elisa3-lib.c']]]
];
