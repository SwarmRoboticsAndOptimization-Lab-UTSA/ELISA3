var searchData=
[
  ['obstacle_5favoid_5foff',['OBSTACLE_AVOID_OFF',['../elisa3-lib_8c.html#ad468464ecacb6f03f493ba8bcfe51bf4',1,'elisa3-lib.c']]],
  ['obstacle_5favoid_5fon',['OBSTACLE_AVOID_ON',['../elisa3-lib_8c.html#a60f37a2c0196ebb01fc81810a0cc44db',1,'elisa3-lib.c']]],
  ['overhead_5fsize',['OVERHEAD_SIZE',['../elisa3-lib_8c.html#a635c69a613273e533212c0bf3c15b8c4',1,'elisa3-lib.c']]]
];
