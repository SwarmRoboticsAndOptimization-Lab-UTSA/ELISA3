var searchData=
[
  ['numoferrors',['numOfErrors',['../elisa3-lib_8c.html#a44b0aa1793d64146a30c67d500c70960',1,'elisa3-lib.c']]],
  ['numofpackets',['numOfPackets',['../elisa3-lib_8c.html#ad361eef48b2074992e616ee6226b1713',1,'elisa3-lib.c']]]
];
