var searchData=
[
  ['sleep_5foff',['SLEEP_OFF',['../elisa3-lib_8c.html#a0842c94ab6817c2e3bebf1512417a09c',1,'elisa3-lib.c']]],
  ['sleep_5fon',['SLEEP_ON',['../elisa3-lib_8c.html#ae0130fe9ae0466278bb918d6354d8eb4',1,'elisa3-lib.c']]]
];
