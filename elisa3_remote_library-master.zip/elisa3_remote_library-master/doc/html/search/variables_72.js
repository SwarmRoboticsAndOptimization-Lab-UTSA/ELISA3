var searchData=
[
  ['redled',['redLed',['../elisa3-lib_8c.html#a20c4975645d2285468324b8fd977f36b',1,'elisa3-lib.c']]],
  ['rightmotsteps',['rightMotSteps',['../elisa3-lib_8c.html#adcdb84652664306340f157be115d48f6',1,'elisa3-lib.c']]],
  ['rightspeed',['rightSpeed',['../elisa3-lib_8c.html#a4005ab9e2ac18411706d7e3ce7c0f453',1,'elisa3-lib.c']]],
  ['robotaddress',['robotAddress',['../elisa3-lib_8c.html#a48da6dba57d79a11b4b96af17983751f',1,'elisa3-lib.c']]],
  ['robtheta',['robTheta',['../elisa3-lib_8c.html#a762d970642e107284e42288a30d656f5',1,'elisa3-lib.c']]],
  ['robxpos',['robXPos',['../elisa3-lib_8c.html#a208f30a6a0bd43cdc10ead6b55c97ac2',1,'elisa3-lib.c']]],
  ['robypos',['robYPos',['../elisa3-lib_8c.html#ad3dba0c4da12e18808243923aad144ff',1,'elisa3-lib.c']]],
  ['rx_5fbuffer',['RX_buffer',['../elisa3-lib_8c.html#a0e7919a152a9dd643803853a92dad6e0',1,'elisa3-lib.c']]]
];
