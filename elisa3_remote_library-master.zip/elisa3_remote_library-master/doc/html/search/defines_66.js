var searchData=
[
  ['front_5fir_5foff',['FRONT_IR_OFF',['../elisa3-lib_8c.html#aa699c9d0d5e3da4a5d98cbdbb67dbcc7',1,'elisa3-lib.c']]],
  ['front_5fir_5fon',['FRONT_IR_ON',['../elisa3-lib_8c.html#afbf8d2e3dda3152ebb64a6f29b3bbd3b',1,'elisa3-lib.c']]]
];
