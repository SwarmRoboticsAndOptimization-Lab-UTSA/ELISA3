var searchData=
[
  ['back_5fir_5foff',['BACK_IR_OFF',['../elisa3-lib_8c.html#a5a92b9b61f656d06efed73731fa520d9',1,'elisa3-lib.c']]],
  ['back_5fir_5fon',['BACK_IR_ON',['../elisa3-lib_8c.html#a2a9c46fa7bc58171841a2ed48c54230e',1,'elisa3-lib.c']]],
  ['batteryadc',['batteryAdc',['../elisa3-lib_8c.html#aa6147fabc094e676515597e5ffee1eed',1,'elisa3-lib.c']]],
  ['batterypercent',['batteryPercent',['../elisa3-lib_8c.html#a4353ab1628e34259b2ea891cb6c5be93',1,'elisa3-lib.c']]],
  ['blueled',['blueLed',['../elisa3-lib_8c.html#a891833fb4e0a825ff2c08aaf02881a7f',1,'elisa3-lib.c']]],
  ['buttonispressed',['buttonIsPressed',['../elisa3-lib_8c.html#ab00113acfdc872762fe2656a33e0a199',1,'buttonIsPressed(int robotAddr):&#160;elisa3-lib.c'],['../elisa3-lib_8h.html#ab00113acfdc872762fe2656a33e0a199',1,'buttonIsPressed(int robotAddr):&#160;elisa3-lib.c']]]
];
