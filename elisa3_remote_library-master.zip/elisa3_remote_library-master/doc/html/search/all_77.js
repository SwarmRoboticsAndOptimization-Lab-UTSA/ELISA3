var searchData=
[
  ['waitformessagetransmission',['waitForMessageTransmission',['../elisa3-lib_8h.html#aa669faf37d452d96f791366050997f27',1,'elisa3-lib.h']]],
  ['waitforupdate',['waitForUpdate',['../elisa3-lib_8c.html#a53d7a7c070f31f89b198212567aecd5c',1,'waitForUpdate(int robotAddr, unsigned long us):&#160;elisa3-lib.c'],['../elisa3-lib_8h.html#a53d7a7c070f31f89b198212567aecd5c',1,'waitForUpdate(int robotAddr, unsigned long us):&#160;elisa3-lib.c']]]
];
