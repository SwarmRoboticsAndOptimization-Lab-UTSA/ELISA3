var searchData=
[
  ['greenled',['greenLed',['../elisa3-lib_8c.html#a3c1c6303dfd374c584d45c6a9456f8ff',1,'elisa3-lib.c']]],
  ['groundambientvalue',['groundAmbientValue',['../elisa3-lib_8c.html#a6eba5fa25df25486e9a1ab8276661d73',1,'elisa3-lib.c']]],
  ['groundvalue',['groundValue',['../elisa3-lib_8c.html#a3a37560e808bafbb43522764228f5891',1,'elisa3-lib.c']]]
];
