var searchData=
[
  ['transferdata',['transferData',['../elisa3-lib_8c.html#a3468014ccaf69f2f9db7149ad0257294',1,'transferData():&#160;elisa3-lib.c'],['../elisa3-lib_8h.html#a3468014ccaf69f2f9db7149ad0257294',1,'transferData():&#160;elisa3-lib.c']]],
  ['turnoffallirs',['turnOffAllIRs',['../elisa3-lib_8c.html#aa43374cfdca7dd29bf5f23c15af8e3c3',1,'turnOffAllIRs(int robotAddr):&#160;elisa3-lib.c'],['../elisa3-lib_8h.html#aa43374cfdca7dd29bf5f23c15af8e3c3',1,'turnOffAllIRs(int robotAddr):&#160;elisa3-lib.c']]],
  ['turnoffbackir',['turnOffBackIR',['../elisa3-lib_8c.html#a3f56d131cd73352447ed70d2971c4d38',1,'turnOffBackIR(int robotAddr):&#160;elisa3-lib.c'],['../elisa3-lib_8h.html#a3f56d131cd73352447ed70d2971c4d38',1,'turnOffBackIR(int robotAddr):&#160;elisa3-lib.c']]],
  ['turnofffrontirs',['turnOffFrontIRs',['../elisa3-lib_8c.html#a06abecb4fa685b8623d64bee78f4a3c3',1,'turnOffFrontIRs(int robotAddr):&#160;elisa3-lib.c'],['../elisa3-lib_8h.html#a06abecb4fa685b8623d64bee78f4a3c3',1,'turnOffFrontIRs(int robotAddr):&#160;elisa3-lib.c']]],
  ['turnoffsmallleds',['turnOffSmallLeds',['../elisa3-lib_8c.html#ac9c6521bc7e642e56d25fa7734e6d8d4',1,'turnOffSmallLeds(int robotAddr):&#160;elisa3-lib.c'],['../elisa3-lib_8h.html#ac9c6521bc7e642e56d25fa7734e6d8d4',1,'turnOffSmallLeds(int robotAddr):&#160;elisa3-lib.c']]],
  ['turnonallirs',['turnOnAllIRs',['../elisa3-lib_8c.html#ac9a0c99282b85301bff4b078836e3ff9',1,'turnOnAllIRs(int robotAddr):&#160;elisa3-lib.c'],['../elisa3-lib_8h.html#ac9a0c99282b85301bff4b078836e3ff9',1,'turnOnAllIRs(int robotAddr):&#160;elisa3-lib.c']]],
  ['turnonbackir',['turnOnBackIR',['../elisa3-lib_8c.html#a5a59bf601409de2fdc5b35bca8288373',1,'turnOnBackIR(int robotAddr):&#160;elisa3-lib.c'],['../elisa3-lib_8h.html#a5a59bf601409de2fdc5b35bca8288373',1,'turnOnBackIR(int robotAddr):&#160;elisa3-lib.c']]],
  ['turnonfrontirs',['turnOnFrontIRs',['../elisa3-lib_8c.html#ac38c39bc7b0769869299f25634515ee1',1,'turnOnFrontIRs(int robotAddr):&#160;elisa3-lib.c'],['../elisa3-lib_8h.html#ac38c39bc7b0769869299f25634515ee1',1,'turnOnFrontIRs(int robotAddr):&#160;elisa3-lib.c']]],
  ['turnonsmallleds',['turnOnSmallLeds',['../elisa3-lib_8c.html#a891635ad934db8d4ee69d7a44b02e601',1,'turnOnSmallLeds(int robotAddr):&#160;elisa3-lib.c'],['../elisa3-lib_8h.html#a891635ad934db8d4ee69d7a44b02e601',1,'turnOnSmallLeds(int robotAddr):&#160;elisa3-lib.c']]],
  ['tv_5fremote_5foff',['TV_REMOTE_OFF',['../elisa3-lib_8c.html#a0ee558c654858d3cc710b12a3be14fd1',1,'elisa3-lib.c']]],
  ['tv_5fremote_5fon',['TV_REMOTE_ON',['../elisa3-lib_8c.html#a627bcd607203209fcbbb03c825e9a902',1,'elisa3-lib.c']]],
  ['tvremote',['tvRemote',['../elisa3-lib_8c.html#a15de6d2d54a817fd54caaac78a9d308f',1,'elisa3-lib.c']]],
  ['tx_5fbuffer',['TX_buffer',['../elisa3-lib_8c.html#a0855ad04c0d4bebd7be7a4f97396b77f',1,'elisa3-lib.c']]]
];
