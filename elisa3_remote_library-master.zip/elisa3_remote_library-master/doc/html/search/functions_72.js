var searchData=
[
  ['resetflagtx',['resetFlagTX',['../elisa3-lib_8c.html#a867388ae76ad41d518daf5065b61507c',1,'resetFlagTX(int robotAddr):&#160;elisa3-lib.c'],['../elisa3-lib_8h.html#a867388ae76ad41d518daf5065b61507c',1,'resetFlagTX(int robotAddr):&#160;elisa3-lib.c']]],
  ['resetmessageissentflag',['resetMessageIsSentFlag',['../elisa3-lib_8c.html#a03953ee5d30ef0f4f25548927b45c13a',1,'resetMessageIsSentFlag(int robotAddr):&#160;elisa3-lib.c'],['../elisa3-lib_8h.html#a03953ee5d30ef0f4f25548927b45c13a',1,'resetMessageIsSentFlag(int robotAddr):&#160;elisa3-lib.c']]],
  ['resetrobotdata',['resetRobotData',['../elisa3-lib_8c.html#a54c3c7a0345a7b0a28f8cc5a0a3abbff',1,'elisa3-lib.c']]],
  ['resumetransferdata',['resumeTransferData',['../elisa3-lib_8c.html#a3ebd8b9081d003e0ef2c072243b79ab4',1,'resumeTransferData():&#160;elisa3-lib.c'],['../elisa3-lib_8h.html#a3ebd8b9081d003e0ef2c072243b79ab4',1,'resumeTransferData():&#160;elisa3-lib.c']]],
  ['robotischarged',['robotIsCharged',['../elisa3-lib_8c.html#a45261bc6251d2939325a7ede5a9dfe37',1,'robotIsCharged(int robotAddr):&#160;elisa3-lib.c'],['../elisa3-lib_8h.html#a45261bc6251d2939325a7ede5a9dfe37',1,'robotIsCharged(int robotAddr):&#160;elisa3-lib.c']]],
  ['robotischarging',['robotIsCharging',['../elisa3-lib_8c.html#a576a1dc52a8b662f52aa93f6c22e8c2c',1,'robotIsCharging(int robotAddr):&#160;elisa3-lib.c'],['../elisa3-lib_8h.html#a576a1dc52a8b662f52aa93f6c22e8c2c',1,'robotIsCharging(int robotAddr):&#160;elisa3-lib.c']]]
];
