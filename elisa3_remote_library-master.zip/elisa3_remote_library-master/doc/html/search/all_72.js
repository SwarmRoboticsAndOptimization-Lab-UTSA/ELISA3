var searchData=
[
  ['rad_5f2_5fdeg',['RAD_2_DEG',['../elisa3-lib_8c.html#a7cc378d5a4e034adadb7cd892d707714',1,'elisa3-lib.c']]],
  ['redled',['redLed',['../elisa3-lib_8c.html#a20c4975645d2285468324b8fd977f36b',1,'elisa3-lib.c']]],
  ['resetflagtx',['resetFlagTX',['../elisa3-lib_8c.html#a867388ae76ad41d518daf5065b61507c',1,'resetFlagTX(int robotAddr):&#160;elisa3-lib.c'],['../elisa3-lib_8h.html#a867388ae76ad41d518daf5065b61507c',1,'resetFlagTX(int robotAddr):&#160;elisa3-lib.c']]],
  ['resetmessageissentflag',['resetMessageIsSentFlag',['../elisa3-lib_8c.html#a03953ee5d30ef0f4f25548927b45c13a',1,'resetMessageIsSentFlag(int robotAddr):&#160;elisa3-lib.c'],['../elisa3-lib_8h.html#a03953ee5d30ef0f4f25548927b45c13a',1,'resetMessageIsSentFlag(int robotAddr):&#160;elisa3-lib.c']]],
  ['resetrobotdata',['resetRobotData',['../elisa3-lib_8c.html#a54c3c7a0345a7b0a28f8cc5a0a3abbff',1,'elisa3-lib.c']]],
  ['resumetransferdata',['resumeTransferData',['../elisa3-lib_8c.html#a3ebd8b9081d003e0ef2c072243b79ab4',1,'resumeTransferData():&#160;elisa3-lib.c'],['../elisa3-lib_8h.html#a3ebd8b9081d003e0ef2c072243b79ab4',1,'resumeTransferData():&#160;elisa3-lib.c']]],
  ['rightmotsteps',['rightMotSteps',['../elisa3-lib_8c.html#adcdb84652664306340f157be115d48f6',1,'elisa3-lib.c']]],
  ['rightspeed',['rightSpeed',['../elisa3-lib_8c.html#a4005ab9e2ac18411706d7e3ce7c0f453',1,'elisa3-lib.c']]],
  ['robot_5fpacket_5fsize',['ROBOT_PACKET_SIZE',['../elisa3-lib_8c.html#ac0288e2815267ede80d0778c1844081e',1,'elisa3-lib.c']]],
  ['robotaddress',['robotAddress',['../elisa3-lib_8c.html#a48da6dba57d79a11b4b96af17983751f',1,'elisa3-lib.c']]],
  ['robotischarged',['robotIsCharged',['../elisa3-lib_8c.html#a45261bc6251d2939325a7ede5a9dfe37',1,'robotIsCharged(int robotAddr):&#160;elisa3-lib.c'],['../elisa3-lib_8h.html#a45261bc6251d2939325a7ede5a9dfe37',1,'robotIsCharged(int robotAddr):&#160;elisa3-lib.c']]],
  ['robotischarging',['robotIsCharging',['../elisa3-lib_8c.html#a576a1dc52a8b662f52aa93f6c22e8c2c',1,'robotIsCharging(int robotAddr):&#160;elisa3-lib.c'],['../elisa3-lib_8h.html#a576a1dc52a8b662f52aa93f6c22e8c2c',1,'robotIsCharging(int robotAddr):&#160;elisa3-lib.c']]],
  ['robtheta',['robTheta',['../elisa3-lib_8c.html#a762d970642e107284e42288a30d656f5',1,'elisa3-lib.c']]],
  ['robxpos',['robXPos',['../elisa3-lib_8c.html#a208f30a6a0bd43cdc10ead6b55c97ac2',1,'elisa3-lib.c']]],
  ['robypos',['robYPos',['../elisa3-lib_8c.html#ad3dba0c4da12e18808243923aad144ff',1,'elisa3-lib.c']]],
  ['rx_5fbuffer',['RX_buffer',['../elisa3-lib_8c.html#a0e7919a152a9dd643803853a92dad6e0',1,'elisa3-lib.c']]]
];
