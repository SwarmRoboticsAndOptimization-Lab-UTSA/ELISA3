var searchData=
[
  ['rad_5f2_5fdeg',['RAD_2_DEG',['../elisa3-lib_8c.html#a7cc378d5a4e034adadb7cd892d707714',1,'elisa3-lib.c']]],
  ['robot_5fpacket_5fsize',['ROBOT_PACKET_SIZE',['../elisa3-lib_8c.html#ac0288e2815267ede80d0778c1844081e',1,'elisa3-lib.c']]]
];
