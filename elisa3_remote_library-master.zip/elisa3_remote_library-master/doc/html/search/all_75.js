var searchData=
[
  ['unused_5fbytes',['UNUSED_BYTES',['../elisa3-lib_8c.html#af485feb53f54b298236422237bc5294f',1,'elisa3-lib.c']]],
  ['usb_2dcomm_2ec',['usb-comm.c',['../usb-comm_8c.html',1,'']]],
  ['usb_2dcomm_2eh',['usb-comm.h',['../usb-comm_8h.html',1,'']]],
  ['usb_5freceive',['usb_receive',['../usb-comm_8c.html#aa5f15d2883e51e35be36b680db5f08d6',1,'usb_receive(char *data, int nbytes):&#160;usb-comm.c'],['../usb-comm_8h.html#aa5f15d2883e51e35be36b680db5f08d6',1,'usb_receive(char *data, int nbytes):&#160;usb-comm.c']]],
  ['usb_5fsend',['usb_send',['../usb-comm_8c.html#aab9500debd97cac679a8fdb5e1f69a64',1,'usb_send(char *data, int nbytes):&#160;usb-comm.c'],['../usb-comm_8h.html#aab9500debd97cac679a8fdb5e1f69a64',1,'usb_send(char *data, int nbytes):&#160;usb-comm.c']]],
  ['usbcommopenedflag',['usbCommOpenedFlag',['../elisa3-lib_8c.html#af2c33723461f5269bd55f0b6b7789881',1,'elisa3-lib.c']]]
];
