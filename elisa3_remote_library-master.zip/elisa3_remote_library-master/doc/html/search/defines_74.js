var searchData=
[
  ['tv_5fremote_5foff',['TV_REMOTE_OFF',['../elisa3-lib_8c.html#a0ee558c654858d3cc710b12a3be14fd1',1,'elisa3-lib.c']]],
  ['tv_5fremote_5fon',['TV_REMOTE_ON',['../elisa3-lib_8c.html#a627bcd607203209fcbbb03c825e9a902',1,'elisa3-lib.c']]]
];
