var searchData=
[
  ['back_5fir_5foff',['BACK_IR_OFF',['../elisa3-lib_8c.html#a5a92b9b61f656d06efed73731fa520d9',1,'elisa3-lib.c']]],
  ['back_5fir_5fon',['BACK_IR_ON',['../elisa3-lib_8c.html#a2a9c46fa7bc58171841a2ed48c54230e',1,'elisa3-lib.c']]]
];
