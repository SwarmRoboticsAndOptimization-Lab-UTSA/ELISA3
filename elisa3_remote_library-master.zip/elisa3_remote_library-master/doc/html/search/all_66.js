var searchData=
[
  ['flagsrx',['flagsRX',['../elisa3-lib_8c.html#a791be530e4d3ce43da27e91b7cbdbe01',1,'elisa3-lib.c']]],
  ['flagstx',['flagsTX',['../elisa3-lib_8c.html#ae9f352d19ca3bdba83664f15fb4d04f7',1,'elisa3-lib.c']]],
  ['freemutexrx',['freeMutexRx',['../elisa3-lib_8c.html#a6405add6e3ecc2e68840192f2e734259',1,'elisa3-lib.c']]],
  ['freemutexthread',['freeMutexThread',['../elisa3-lib_8c.html#a58621b2c8128b29bc6b033ba9acb9adb',1,'elisa3-lib.c']]],
  ['freemutextx',['freeMutexTx',['../elisa3-lib_8c.html#a53c8f28bb1390e07ccfb66a485efced4',1,'elisa3-lib.c']]],
  ['front_5fir_5foff',['FRONT_IR_OFF',['../elisa3-lib_8c.html#aa699c9d0d5e3da4a5d98cbdbb67dbcc7',1,'elisa3-lib.c']]],
  ['front_5fir_5fon',['FRONT_IR_ON',['../elisa3-lib_8c.html#afbf8d2e3dda3152ebb64a6f29b3bbd3b',1,'elisa3-lib.c']]]
];
