#include <stdio.h>

int usb_send(char* data, int nbytes);

int usb_receive(char* data, int nbytes);

int openCommunication();

void closeCommunication();


